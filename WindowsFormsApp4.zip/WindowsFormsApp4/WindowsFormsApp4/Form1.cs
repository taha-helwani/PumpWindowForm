﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp4
{
    public partial class SyringePump : Form
    {
        public SyringePump()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = "Search";
            textBox1.ForeColor = Color.DarkGray;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            ToolTip hint = new ToolTip();
            bool isValid0 = textBox1.Text.Length >= 3;
            if (isValid0 == true)
            {
                string word1 = textBox1.Text.Substring(0, 3);
                if (word1 == "DIA" || word1 == "PHN" || word1 == "FUN" || word1 == "RAT" || word1 == "VOL" || word1 == "DIR" || word1 == "PUR" || word1 == "STP")
                {
                    label1.BackColor = Color.Green;
                    if(textBox1.Text.Length > 3)
                    {
                        label1.BackColor = Color.Gray;
                        if (textBox1.Text.Length == 7)
                        {
                            string word2 = textBox1.Text.Substring(4, 3);
                            if (word1 == "FUN" && word2 == "RAT" || word2 == "FIl" || word2 == "INC" || word2 == "DEC" || word2 == "STP" || word2 == "PRI" || word2 == "LPS" || word2 == "LPE" || word2 == "PAS" || word2 == "EVR" || word2 == "CLD" || word2 == "TRG" || word2 == "BEP" || word2 == "OUT")
                            {
                                label1.BackColor = Color.Green;
                            }
                            else
                                label1.BackColor = Color.Red;
                        }
                    }
                }
            
            else
            {
                label1.BackColor = Color.Red;
            }
        }
            else
            {
                label1.BackColor = SystemColors.ButtonShadow;

            }

            
            /*
            if (textBox1.Text != "" && textBox1.Text != "Search")
            {
                int firstTextBoxNumber;
                firstTextBoxNumber = int.Parse(textBox1.Text);
                if (firstTextBoxNumber > 100)

                {
                    label1.BackColor = Color.Red;
                }
                */
            }
        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_Enter(object sender, EventArgs e)
        {
            textBox1.BorderStyle = BorderStyle.None;
            if (textBox1.Text == "Search")
            {
                textBox1.Text = "";
                textBox1.ForeColor = Color.Black;

            }

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }

}
